from .kapa import kapa
from .kapa import conv_MQtable
